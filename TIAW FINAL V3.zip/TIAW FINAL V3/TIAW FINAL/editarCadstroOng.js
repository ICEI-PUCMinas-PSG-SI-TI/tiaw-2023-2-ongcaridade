

/*PARA ATUALIZAR A IMAGEM*/
// Declare a variável global
var imagePath = "";

function updateImage() {
  updateImage1(); 
  updateImage2(); 
}

function updateImage1() {
  var img = document.querySelector('#avatarImage');
  var fileInput = document.querySelector('input[type=file]');
  var file = fileInput.files[0];
  var reader = new FileReader();

  if (file) {
    reader.onloadend = function () {
      img.src = reader.result;

      // Atualize a variável global
      imagePath = reader.result;
    }
    reader.readAsDataURL(file);
  } else {
    alert('Por favor, selecione um arquivo antes de atualizar a imagem.');
  }
}

function updateImage2() {
  var img = document.querySelector('#avatarImage2');
  var fileInput = document.querySelector('input[type=file]');
  var file = fileInput.files[0];
  var reader = new FileReader();

  if (file) {
    reader.onloadend = function () {
      img.src = reader.result;

      // Atualize a variável global
      imagePath = reader.result;
    }
    reader.readAsDataURL(file);
  } else {
    // Faça algo se o arquivo não estiver presente
  }
}

// Agora, você pode acessar a variável global "imagePath" em qualquer parte do seu código.




function formatarTelefone(input) {
  // Remove todos os caracteres não numéricos do valor
  input.value = input.value.replace(/\D/g, '');
  
  // Insere um hífen após os primeiros 5 dígitos (se houver mais de 5 dígitos)
  if (input.value.length > 5) {
      input.value = input.value.slice(0, 5) + '-' + input.value.slice(5);
  }
}

function Dados() {
  UpdadeText(); 
  salvarDados(); 
}

function salvarDados() {
  // Obter os valores dos campos do formulário
  var nomeOng = document.getElementById("nomeOng").textContent;
  var endereco = document.getElementById("endereco").value;
  var cidade = document.getElementById("cidade").value;
  var estado = document.getElementById("estado").value;
  var cep = document.getElementById("cep").value;
  var telefone = document.getElementById("telefone").value;
  var email = document.getElementById("email").value;
  var instagram = document.getElementById("instagram").value;

  // Armazenar os valores em localStorage
  localStorage.setItem("nomeOng", nomeOng);
  localStorage.setItem("endereco", endereco);
  localStorage.setItem("cidade", cidade);
  localStorage.setItem("estado", estado);
  localStorage.setItem("cep", cep);
  localStorage.setItem("telefone", telefone);
  localStorage.setItem("email", email);
  localStorage.setItem("instagram", instagram);

    // Convertendo os dados para string e armazenando no localStorage
    localStorage.setItem("dadosOng", JSON.stringify(dados));

    alert("Dados salvos com sucesso!");

};


function UpdadeText() {
  var novoNome = document.getElementById("inputNomeOng").value;
  var nomeOng = document.getElementById("nomeOng");


  var inputIds = ["endereco", "cidade", "estado", "cep", "telefone", "email", "instagram"];


  var algumCampoPreenchido = inputIds.some(function (id) {
    var valorCampo = document.getElementById(id).value.trim();
    return valorCampo !== "";
  });

  if (novoNome.trim() !== "" || algumCampoPreenchido) {
    nomeOng.textContent = novoNome;
    alert("Dados salvos com sucesso!");
  } else {
    alert("Por favor, insira pelo menos um valor antes de atualizar os textos.");

  }
}

document.addEventListener("DOMContentLoaded", function() {
  const menuToggle = document.getElementById("menu-toggle");
  const sidebar = document.getElementById("sidebar");

  menuToggle.addEventListener("click", function() {
    sidebar.classList.toggle("show-menu");
  });
});


/*PAGINA PARA SAIR*/
window.onload = function () {
  var meuModal = new bootstrap.Modal(document.getElementById('meuModal'));
  meuModal.show();

  // Redirecionar para outra página após 5 segundos
  setTimeout(function() {
      window.location.href = "https://google.com";
  }, 5000);
}