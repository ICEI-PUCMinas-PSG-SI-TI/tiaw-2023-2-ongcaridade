function salvarComentarios() {
    localStorage.setItem('comentarios', JSON.stringify(comentarios));
}

function carregarComentarios() {
    var comentariosSalvos = localStorage.getItem('comentarios');
    return comentariosSalvos ? JSON.parse(comentariosSalvos) : [
        { "autor": "João", "texto": "Ótima notícia!" },
        { "autor": "Maria", "texto": "Estou ansiosa por mais informações." },
        { "autor": "Suellen", "texto": "Amoo essa Ong" },
        { "autor": "Rosa Angelica", "texto": "Gostaria de saber mais sobre a ONG" }
    ];
}

var comentarios = carregarComentarios();

function renderizarComentarios() {
    var comentariosContainer = document.getElementById("comentarios");
    comentariosContainer.innerHTML = ""; // Limpar conteúdo atual

    for (var i = 0; i < comentarios.length; i++) {
        var cardDiv = document.createElement("div");
        cardDiv.className = "card comentario-card mb-4"; // Adicionando a classe "comentario-card"

        var cardBodyDiv = document.createElement("div");
        cardBodyDiv.className = "card-body";

        var autorH5 = document.createElement("h5");
        autorH5.className = "card-title";
        autorH5.textContent = comentarios[i].autor;

        var textoP = document.createElement("p");
        textoP.className = "card-text";
        textoP.textContent = comentarios[i].texto;

        var removerBtn = document.createElement("button");
        removerBtn.textContent = "Remover";
        removerBtn.className = "btn btn-danger";
        // Utilizando uma função anônima para capturar o valor atual de i
        (function(index) {
            removerBtn.onclick = function() {
                removerComentario(index);
            };
        })(i);

        cardBodyDiv.appendChild(autorH5);
        cardBodyDiv.appendChild(textoP);
        cardBodyDiv.appendChild(removerBtn);

        cardDiv.appendChild(cardBodyDiv);

        comentariosContainer.appendChild(cardDiv);
    }
}

function adicionarComentario() {
    var novoComentario = {
        "autor": document.getElementById("author").value,
        "texto": document.getElementById("comment").value
    };

    comentarios.unshift(novoComentario);
    salvarComentarios();
    renderizarComentarios();
}

function removerComentario(index) {
    comentarios.splice(index, 1);
    salvarComentarios();
    renderizarComentarios();
}

// Inicializar a exibição dos comentários
window.onload = function() {
    renderizarComentarios();

    // Verifica se o usuário está logado
    var usuarioLogado = localStorage.getItem('usuarioLogado');

    // Se estiver logado, exibe os botões de "Remover"
    if (usuarioLogado === 'true') {
        var botoesRemover = document.querySelectorAll('.btn-danger');

        botoesRemover.forEach(function(botao) {
            botao.style.display = 'inline-block';
        });
    } else {
        // Se não estiver logado, esconde os botões de "Remover"
        var botoesRemover = document.querySelectorAll('.btn-danger');

        botoesRemover.forEach(function(botao) {
            botao.style.display = 'none';
        });
    }
};
