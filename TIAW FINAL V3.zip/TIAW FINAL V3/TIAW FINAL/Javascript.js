

  var map = L.map('map').setView([-19.9208, -43.9372], 10); 
  
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors'
  }).addTo(map);
  
  var ong = [
    { name: 'ONG A', coordinates: [-19.9440, -43.9406] },
    { name: 'ONG B', coordinates: [-19.9123, -43.9256] },
  ];
  
  ongs.forEach(ong => {
    L.marker(ong.coordinates)
      .addTo(map)
      .bindPopup(`<h6>${ong.name}</h6>`);
  });
  

  document.addEventListener('DOMContentLoaded', function () {
    // Verifica se o usuário está logado
    var usuarioLogado = localStorage.getItem('usuarioLogado');

    // Se estiver logado, exibe o menu
    if (usuarioLogado === 'true') {
      document.getElementById('MENU').style.display = 'flex';
    } else {
      // Se não estiver logado, esconde o menu
      document.getElementById('MENU').style.display = 'none';
    }
  });
  