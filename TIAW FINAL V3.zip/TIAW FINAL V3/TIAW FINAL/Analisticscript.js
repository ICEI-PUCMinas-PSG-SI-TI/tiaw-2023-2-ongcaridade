document.addEventListener('DOMContentLoaded', async function () {
  try {
    // Buscar dados do servidor JSON
    const response = await fetch("https://jsonserver-tiaw1--ingridmendes1.repl.co/paginaOngs");
    const ongsData = await response.json();

    // Log dos dados do servidor
    console.log("Dados do servidor:", ongsData);

    // Verificar se os dados do gráfico existem
    if (ongsData[0].charts) {
      // Obter o ID da ONG a partir dos parâmetros da URL
      const urlParams = new URLSearchParams(window.location.search);
      const ongId = parseInt(urlParams.get('id'));

      // Encontrar a ONG correspondente
      const ong = ongsData.find(ong => ong.ongInfo.id === ongId);

      // Verificar se a ONG foi encontrada
      if (ong) {
        // Atualizar os valores na página com base na ONG
        document.getElementById("totalAccesses").innerText = ong.analytics.totalAccesses;
        document.getElementById("totalAdoptions").innerText = ong.analytics.totalAdoptions;
        document.getElementById("newFormsToReview").innerText = ong.analytics.newFormsToReview;

        // Atualizar a foto de capa
        const capaElement = document.getElementById("capa");
        const imgElement = document.createElement("img");
        imgElement.className = "img-responsive";
        imgElement.src = ong.ongInfo.fotoCapa || 'placeholder.jpg';
        imgElement.alt = "Foto de Capa";
        capaElement.innerHTML = "";
        capaElement.appendChild(imgElement);

        // Configuração dos gráficos
        const accessData = {
          labels: ["Janeiro", "Fevereiro", "Março", "Abril", "Maio"],
          datasets: [{
            label: 'Acessos Mensais',
            data: ong.analytics.accessData || [100, 150, 200, 180, 250],
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
          }]
        };

        const adoptionData = {
          labels: ["Cachorro", "Gato"],
          datasets: [{
            label: 'Animais Adotados por Tipo',
            data: ong.analytics.adoptionData || [200, 80],
            backgroundColor: ['rgba(54, 162, 235, 0.6)', 'rgba(31, 73, 125, 0.6)'],
            borderColor: ['rgba(54, 162, 235, 1)', 'rgba(31, 73, 125, 1)'],
            borderWidth: 1
          }]
        };

        const sexData = {
          labels: ["Macho", "Fêmea"],
          datasets: [{
            label: 'Sexo dos Animais Adotados',
            data: ong.analytics.sexData || [120, 180],
            backgroundColor: ['rgba(54, 162, 235, 0.6)', 'rgba(31, 73, 125, 0.6)'],
            borderColor: ['rgba(54, 162, 235, 1)', 'rgba(31, 73, 125, 1)'],
            borderWidth: 1
          }]
        };

        const formStatusData = {
          labels: ["Aprovados", "Recusados", "Novos Formulários"],
          datasets: [{
            label: 'Status dos Formulários',
            data: ong.analytics.formStatusData || [300, 250, ong.analytics.newFormsToReview],
            backgroundColor: ['rgba(54, 162, 235, 0.6)', 'rgba(31, 73, 125, 0.6)', 'rgba(19, 66, 125,1)'],
            borderColor: ['rgba(54, 162, 235, 1)', 'rgba(31, 73, 125, 0.6)', 'rgba(19, 66, 125,1)'],
            borderWidth: 1
          }]
        };

        // Configuração dos gráficos (continuação)
        const accessCtx = document.getElementById("accessChart").getContext('2d');
        const accessChart = new Chart(accessCtx, {
          type: 'line',
          data: accessData,
          options: {
            responsive: false
          }
        });

        const adoptionCtx = document.getElementById("adoptionChart").getContext('2d');
        const adoptionChart = new Chart(adoptionCtx, {
          type: 'bar',
          data: adoptionData,
          options: {
            responsive: false
          }
        });

        const sexCtx = document.getElementById("sexChart").getContext('2d');
        const sexChart = new Chart(sexCtx, {
          type: 'pie',
          data: sexData,
          options: {
            responsive: false
          }
        });

        const formStatusCtx = document.getElementById("formStatusChart").getContext('2d');
        const formStatusChart = new Chart(formStatusCtx, {
          type: 'pie',
          data: formStatusData,
          options: {
            responsive: false
          }
        });

        // Código para manipulação dos formulários
        const formulariosGuardados = ong.forms || [];
        const formulariosContainer = document.getElementById("formularios");

        if (formulariosGuardados.length === 0) {
          const semFormulariosMessage = document.createElement("p");
          semFormulariosMessage.textContent = "Nenhum formulário de adoção pendente.";
          formulariosContainer.appendChild(semFormulariosMessage);
        } else {
          formulariosGuardados.forEach((formulario, index) => {
            const formularioDiv = document.createElement("div");
            formularioDiv.classList.add("formulario");

            const titulo = document.createElement("h2");
            titulo.textContent = `Formulário ${formulario.id}`;
            formularioDiv.appendChild(titulo);

            const listaInformacoes = document.createElement("ul");
            for (const key in formulario) {
              if (formulario.hasOwnProperty(key)) {
                const informacaoItem = document.createElement("li");

                if (key === 'adotante') {
                  const adotanteInfo = formulario[key];
                  for (const adotanteKey in adotanteInfo) {
                    if (adotanteInfo.hasOwnProperty(adotanteKey)) {
                      const adotanteItem = document.createElement("li");
                      adotanteItem.innerHTML = `<strong>${adotanteKey}:</strong> ${adotanteInfo[adotanteKey]}`;
                      listaInformacoes.appendChild(adotanteItem);
                    }
                  }
                } else {
                  informacaoItem.innerHTML = `<strong>${key}:</strong> ${formulario[key]}`;
                  listaInformacoes.appendChild(informacaoItem);
                }
              }
            }

            const aprovarButton = document.createElement("button");
            aprovarButton.innerHTML = `Aprovar`;
            aprovarButton.className = "approve";
            aprovarButton.addEventListener("click", function () {
              alert(`Formulário ${formulario.id} aprovado!`);
              formulario.status = "Aprovado";
              aprovarButton.disabled = true;
              reprovarButton.disabled = true;

              // Atualizar o número de novos formulários
              ong.analytics.newFormsToReview--;
              aprovarButton.classList.add("lockedA");
              reprovarButton.classList.add("locked");
              document.getElementById("newFormsToReview").innerText = ong.analytics.newFormsToReview;

              // Atualizar o gráfico de status dos formulários
              ong.analytics.approvedForms += 1;
              ong.analytics.newForms -= 1;
              updateChart(formStatusChart, [ong.analytics.approvedForms, ong.analytics.rejectedForms, ong.analytics.newForms]);
            });

            const reprovarButton = document.createElement("button");
            reprovarButton.innerHTML = `Reprovar`;
            reprovarButton.className = "reject";
            reprovarButton.addEventListener("click", function () {
              alert(`Formulário ${formulario.id} reprovado!`);
              formulario.status = "Reprovado";
              aprovarButton.disabled = true;
              reprovarButton.disabled = true;
              reprovarButton.classList.add("lockedR");
              aprovarButton.classList.add("locked");
              // Atualizar o número de novos formulários
              ong.analytics.newFormsToReview--;
              document.getElementById("newFormsToReview").innerText = ong.analytics.newFormsToReview;
              ong.analytics.newForms -= 1;

              // Atualizar o gráfico de status dos formulários
              ong.analytics.rejectedForms += 1;
              updateChart(formStatusChart, [ong.analytics.approvedForms, ong.analytics.rejectedForms, ong.analytics.newForms]);
            });

            if (formulario.status === "Aprovado" || formulario.status === "Reprovado") {
              aprovarButton.disabled = true;
              reprovarButton.disabled = true;
            }

            formularioDiv.appendChild(listaInformacoes);
            formularioDiv.appendChild(aprovarButton);
            formularioDiv.appendChild(reprovarButton);

            formulariosContainer.appendChild(formularioDiv);
          });
        }
      }
    }
  } catch (error) {
    console.error("Erro ao buscar dados do servidor:", error);
  }
});

function updateChart(chart, data) {
  chart.data.datasets[0].data = data;
  chart.update();
}
