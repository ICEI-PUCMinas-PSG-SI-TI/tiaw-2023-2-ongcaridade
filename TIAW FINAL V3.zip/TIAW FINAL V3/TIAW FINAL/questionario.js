// Carrega as perguntas do arquivo JSON
fetch('https://jsonservertiaw.nathielleguimar.repl.co/perguntas')
  .then(response => {
    if (!response.ok) {
      throw new Error('Erro ao carregar perguntas');
    }
    return response.json();
  })
  .then(data => {
    console.log("Resposta do servidor (antes):", data);

    // Verifica se a resposta contém perguntas e ajusta conforme necessário
    const perguntas = data.perguntas || data;
    if (!perguntas || !Array.isArray(perguntas)) {
      console.error('Formato de perguntas inválido:', data);
      return;
    }

    // Chama a função para exibir perguntas dinamicamente
    exibirPerguntas(perguntas);
  })
  .catch(error => console.error('Erro:', error));

// Função para exibir perguntas dinamicamente
function exibirPerguntas(perguntas) {
  const form = document.getElementById('questionarioForm');

  perguntas.forEach(pergunta => {
    const div = document.createElement('div');
    div.innerHTML = `
      <label>${pergunta.pergunta}</label>
      <select id="${pergunta.id}">
        <option value="sim">Sim</option>
        <option value="nao">Não</option>
      </select>
    `;
    form.appendChild(div);
  });
}

// Função para salvar respostas (versão simulada)
function salvarRespostas() {
  const respostas = {
    "respostas": [
      {"pergunta": "Você já teve animais de estimação anteriormente?", "resposta": "sim"},
      {"pergunta": "Você pratica atividades físicas regularmente? Você incluiria seu animal nessas atividades?", "resposta": "não"},
      {"pergunta": "Você está disposto a fornecer cuidados veterinários necessários, incluindo vacinas e check-ups regulares?", "resposta": "sim"},
      {"pergunta": "Está ciente sobre as características e necessidades específicas da espécie de animal que está considerando ter como animal de estimação?", "resposta": "sim"},
      {"pergunta": "Você já verificou as políticas de moradia ou possíveis restrições que podem afetar a posse de animais em seu local de residência?", "resposta": "sim"}
    ]
    
  };

  const numRespostasSim = respostas.respostas.filter(resp => resp.resposta === "sim").length;
  console.log("Respostas simuladas:", respostas);
  if (numRespostasSim > 2) {
    console.log("index.html");
    // window.location.href = "formulario_adocao.html";
  } else {
    console.log("Redirecionando para https://www.astra-sa.com/destaques/como-cuidar-de-um-cachorro-7-dicas-para-agradar-seu-pet/");
    window.location.replace("https://www.astra-sa.com/destaques/como-cuidar-de-um-cachorro-7-dicas-para-agradar-seu-pet/");
  }



  mostrarMensagemSalvo(); // Chama a função para exibir a mensagem
}

// Função para exibir mensagem informando que as alterações foram salvas
function mostrarMensagemSalvo() {
  const mensagemDiv = document.createElement('div');
  mensagemDiv.innerHTML = '<p>Alterações foram salvas! Você será redirecionado. </p>';
  mensagemDiv.classList.add('mensagem-salvo'); // Adiciona uma classe para estilização (opcional)

  // Adiciona a mensagem antes do botão salvar
  const salvarButton = document.querySelector('button');
  salvarButton.parentNode.insertBefore(mensagemDiv, salvarButton.nextSibling);

  // Remove a mensagem após alguns segundos
  setTimeout(() => {
    mensagemDiv.remove();
  }, 3000); // A mensagem será removida após 3 segundos (3000 milissegundos)
}
