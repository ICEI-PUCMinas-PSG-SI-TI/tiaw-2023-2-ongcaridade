function salvarComentarios() {
    localStorage.setItem('comentarios', JSON.stringify(comentarios));
}

function carregarComentarios() {
    var comentariosSalvos = localStorage.getItem('comentarios');
    return comentariosSalvos ? JSON.parse(comentariosSalvos) : [
        { "autor": "João", "texto": "Ótima notícia!" },
        { "autor": "Maria", "texto": "Estou ansiosa por mais informações." },
        { "autor": "Suellen", "texto": "Amoo essa Ong" },
        { "autor": "Rosa Angelica", "texto": "Gostaria de saber mais sobre a ONG" }
    ];
}

var comentarios = carregarComentarios();

function renderizarComentarios() {
    var comentariosContainer = document.getElementById("comentarios");
    comentariosContainer.innerHTML = ""; // Limpar conteúdo atual

    for (var i = 0; i < comentarios.length; i++) {
        comentariosContainer.innerHTML +=
            '<div class="comentario mb-4">' +
            '<h1>' + comentarios[i].autor + '</h1>' +
            '<p>' + comentarios[i].texto + '</p>' +
            '<button onclick="removerComentario(' + i + ')" class="btn btn-danger">Remover</button>' +
            '</div>';
    }
}

function adicionarComentario() {
    var novoComentario = {
        "autor": document.getElementById("author").value,
        "texto": document.getElementById("comment").value
    };

    comentarios.push(novoComentario);
    salvarComentarios();
    renderizarComentarios();
}

function removerComentario(index) {
    comentarios.splice(index, 1);
    salvarComentarios();
    renderizarComentarios();
}

// Inicializar a exibição dos comentários
window.onload = renderizarComentarios;