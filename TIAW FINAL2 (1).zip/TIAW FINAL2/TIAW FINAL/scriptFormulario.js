const form = document.getElementById('adoptionForm');

form.addEventListener('submit', function (event) {
  event.preventDefault();

  const formData = new FormData(form);
  const data = {};

  formData.forEach((value, key) => {
    data[key] = value;
  });

  console.log('Dados do formulário:', data);

  fetch('https://jsontiaw.yagomarques6.repl.co/adoptions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  })
    .then(response => {
      console.log('Resposta do servidor:', response);
      if (!response.ok) {
        throw new Error(`Erro no servidor: ${response.status}`);
      }
      return response.json();
    })
    .then(result => {
      console.log('Dados enviados com sucesso:', result);
      // Lidar com a resposta do servidor, se necessário
    })
    .catch(error => {
      console.error('Erro ao enviar dados:', error);
      // Lidar com erros de envio
    });

  // Armazenar os dados no armazenamento local
  localStorage.setItem('adoptionData', JSON.stringify(data));

  // Exibir os dados armazenados
  exibirDadosArmazenados();
});

function exibirDadosArmazenados() {
  const dadosArmazenados = localStorage.getItem('adoptionData');
  if (dadosArmazenados) {
    const dadosParseados = JSON.parse(dadosArmazenados);

    const divExibicao = document.createElement('div');
    divExibicao.innerHTML = '<h2>Dados do Formulário Armazenados</h2>';

    for (const chave in dadosParseados) {
      divExibicao.innerHTML += `<p><strong>${chave}:</strong> ${dadosParseados[chave]}</p>`;
    }

    document.body.appendChild(divExibicao);
  }
}
